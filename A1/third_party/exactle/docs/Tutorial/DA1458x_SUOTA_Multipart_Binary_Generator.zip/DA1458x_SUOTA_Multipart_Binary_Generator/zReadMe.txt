Please install python 3.5

Application folder architecture contains -

bin\hex2bin.exe
bin\mkimage.exe

input\fw_1.hex
input\fw_1_version.h

input\fw_2.hex
input\fw_2_version.h

input\secondary_bootloader.hex

project_img.py

Please rename you hex files according to the input folder file name,
if you want to activate encryption process please open the project_img.py
and configure only the -

##################### USER DATA CONFIGURATION SECTION #############

section.

NOTE: This is a software which is not maintained by Dialog Semiconductor, your are free to modify the software.
Dialog Semiconductor is not liable for any sort of issues and modification made in this software.
It is only used for quick support and demonstration purpose. 